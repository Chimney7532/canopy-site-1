# Canopy

An English public website and member community with account approval, connections, direct messages, discussions, voting, ideas, project stages, tasks, events and an administrator workspace.

## Current source layout

The published public website is `site/index.html`, with its styles, animations, and media in `public/assets/`. `build/sites-worker.ts` serves that website and routes `/api/forum`, `/api/events`, and `/api/content` to `server/`.

`app/` and `components/canopy-app.tsx` still serve the account, setup, and administrative routes; they are not duplicate public-site files to remove. `db/` and `drizzle/` retain the database schema and migrations. Shared fonts live in `public/assets/`, including their license files. Only UI components used by the retained routes are included in `components/ui/`.

## Run locally

For a fresh checkout, run `npm run install:ci`, then `node scripts/setup-local-db.mjs` and `npm run dev`. The local website opens at `http://127.0.0.1:5173/`.

This edition replaces the previous site with the supplied v114 source. The public member directory lives in `server/public-people.mjs`; it includes Chimney Y. and does not create login accounts. Canyon L., Qi J., and Shardul M. use the supplied portraits. Other members use initials until photographs are supplied.

Events use complete posters with a short introduction outside the image. The Care at a Distance page also includes the two supplied panel photographs. Project pages describe Founder Dinners and Startup Sourcing with N1AC. Fictional sample members and calendar entries are not displayed. Room remains the supplied coming-soon page; account and administrator routes remain available separately.

Use Node 22.13 or newer. `npm install`, then `npm run dev`. The Sites starter uses Vinext/React and Cloudflare Workers. The D1 binding is `DB` in `.openai/hosting.json`.

For a fresh local database, create an ignored Wrangler config with D1 database id `00000000-0000-4000-8000-000000000000`, then execute the generated `drizzle/*.sql` migrations using Wrangler `d1 execute DB --local --persist-to .wrangler/state --file ...`. Set the local `CANOPY_SETUP_KEY` in an ignored `.dev.vars` file. Production secrets are managed by Sites and must never be committed.

## First administrator

1. Register your own account at `/join`.
2. While signed in, open `/setup`.
3. Enter the private, one-time setup key from `.sites-runtime/admin-setup.txt` in this checkout.
4. Open `/community/admin` to approve members and publish content.

The setup key is consumed once, atomically. Registration alone never grants elevated access. The setup file, development secrets, local databases and test fixtures are ignored by Git and excluded from publishing.

## Routes

Public: `/`, `/explore`, `/events`, `/people`, `/about`, `/contact`, `/join`, `/signin`, `/privacy`.

Members: `/community`, `/community/people`, `/community/conversations`, `/community/build`, `/community/build/:id`, `/community/events`, `/community/messages`, `/community/notifications`, `/community/settings`, `/community/admin`.

Read-only sample community: `/preview` with the same subroutes. Sample identities and events are fictional and never seeded into the live database.

## Development references

- `DESIGN.md`: visual direction, design tokens, component rules and photo attribution.
- `docs/DATA_MODEL.md`: 23-table schema, relationships, access rules and operational boundaries.
- `docs/VALIDATION.md`: checks completed for this implementation.
- `db/schema.ts`: schema definitions.
- `app/api/route.ts`: authenticated API actions and filtered read model.

Run `npx tsc --noEmit` and `npm run lint`. Generate migrations with `npm run db:generate` after schema changes. Applied migrations are immutable. Use the Sites build/publish workflow for production artifacts.
