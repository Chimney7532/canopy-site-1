import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../public/assets/ink-titles.js',import.meta.url),'utf8');
const code=source.slice(source.indexOf('function usesAnchoredMotion('),source.indexOf('function transition('));
const anchored=vm.runInNewContext(code+'\nusesAnchoredMotion');
const title=(x,y,dx=0,dy=0)=>({anchor:{x,y,scale:1},eye:{x:x+dx,y:y+dy,scale:1}});
test('Projects and People keep their anchored ripple regardless of pointer direction',()=>{
 for(const dx of [-15,0,15])for(const dy of [-6,0,6]){
  assert.equal(anchored(title(560,130,dx,dy),title(560,130)),true);
 }
});
test('gaze cannot turn a nearby Home transition into an unnecessary jump',()=>{
 assert.equal(anchored(title(600,130,15,6),title(525,130)),true);
});
test('distant titles still travel and interrupted flights retain their trajectory',()=>{
 assert.equal(anchored(title(560,130),title(900,130)),false);
 assert.equal(anchored({...title(560,130),frozen:{},motion:'flight'},title(560,130)),false);
 assert.equal(anchored({...title(560,130),frozen:{},motion:'anchored'},title(560,130)),true);
});
test('capture separates title anchor from a looking, half-closed pupil',()=>{
 const matrix={a:1,b:0,c:0,d:.5,e:15,f:47.829};
 const base={a:1,b:0,c:0,d:1,e:0,f:0};
 const pupil={getAttribute:()=> 'pupil',getScreenCTM:()=>matrix,closest:s=>s==='[data-ink-eye]'?{getScreenCTM:()=>base}:null,hasAttribute:k=>k==='data-ink-pupil',classList:{contains:()=>false}};
 const body={...pupil,getAttribute:()=> 'body',getScreenCTM:()=>base,closest:()=>null,hasAttribute:()=>false,dataset:{}};
 const part={getBoundingClientRect:()=>({left:0,right:800,top:0,bottom:166}),matches:()=>false,querySelectorAll:s=>s==='path'?[body,pupil]:[]};
 const captureCode=source.slice(source.indexOf('function capture(parts)'),source.indexOf('function usesAnchoredMotion('));
 const context={DATA:{source:{pupil:'pupil',star:'star',opy:'body'}},aperturePath:'aperture',split:d=>[d],polygon:pts=>JSON.stringify(pts),sample:(d,m)=>[[m.a*428.981+m.e,m.d*83.658+m.f]],Math};
 const capture=vm.runInNewContext(captureCode+'\ncapture',context);
 const result=capture([part]);
 assert.equal(result.anchor.y,83.658);
 assert.equal(result.eye.y,89.658);
 assert.equal(result.eye.x,result.anchor.x+15);
 assert.ok(result.pupilD);assert.ok(result.starD);
});
