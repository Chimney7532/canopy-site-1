/* Each deliberate gesture immediately selects a fully aligned title. */
window.CanopyStoryScroll = {
  mount({main,anchor,blocked}) {
    const controller=new AbortController(), reduced=matchMedia('(prefers-reduced-motion:reduce)');
    const chapters=[...main.querySelectorAll('[data-can-word]')];
    const projectChapter=main.querySelector?.('.home-build'),projectReel=projectChapter?.querySelector('.project-reel');
    let frame=0,moving=false,latched=false,lastWheel=-Infinity,amount=0,touch=null,destination=null;
    let lastMagnitude=0,lastDirection=0,lastCommit=-Infinity,position=scrollY,velocity=0,lastFrame=0;
    const listen=(type,fn,options={})=>window.addEventListener(type,fn,{signal:controller.signal,...options});
    const inactive=()=>!anchor.isConnected||blocked();
    const editable=target=>target.closest?.('input,textarea,select,[contenteditable="true"],dialog,[role="dialog"]');
    function stops() {
      const offset=parseFloat(getComputedStyle(anchor).top)||0, y=scrollY;
      const max=Math.max(0,document.documentElement.scrollHeight-innerHeight), result=[];
      chapters.forEach((chapter,i)=>{
        const start=i?chapter.getBoundingClientRect().top+y-offset:0;
        result.push(Math.max(0,Math.min(max,start)));
      });
      return [...new Set(result.map(Math.round))].sort((a,b)=>a-b);
    }
    const announceMotion=moving=>document.dispatchEvent(new CustomEvent('canopy-story-motion',{detail:{moving}}));
    function finish() {
      if(destination!==null)window.scrollTo({top:destination,behavior:'instant'});
      cancelAnimationFrame(frame);frame=0;moving=false;destination=null;
      velocity=0;position=scrollY;announceMotion(false);
    }
    function tick(now){
      if(inactive()){cancelAnimationFrame(frame);frame=0;moving=false;destination=null;velocity=0;announceMotion(false);return;}
      const dt=Math.min(.05,Math.max(.001,(now-lastFrame)/1000));lastFrame=now;
      // Analytic critically damped motion: no restart, bounce, or velocity discontinuity.
      const omega=12.5,error=position-destination,c=velocity+omega*error,decay=Math.exp(-omega*dt);
      position=destination+(error+c*dt)*decay;
      velocity=(velocity-omega*c*dt)*decay;
      window.scrollTo({top:position,behavior:'instant'});
      if(Math.abs(position-destination)<.75&&Math.abs(velocity)<8){finish();return;}
      frame=requestAnimationFrame(tick);
    }
    function go(target) {
      if(!moving&&Math.abs(target-scrollY)<2)return false;
      lastCommit=performance.now();destination=target;
      if(reduced.matches){finish();return true;}
      if(!moving){
        position=scrollY;velocity=0;lastFrame=lastCommit;moving=true;announceMotion(true);
        frame=requestAnimationFrame(tick);
      }
      return true;
    }
    function requestStep(direction){
      const points=stops();
      // A new gesture updates the selected chapter immediately, even mid-flight.
      // Reverse input undoes the current trip; no cooldown or pending queue.
      const y=moving?destination:scrollY;
      const projectStop=projectChapter?Math.round(projectChapter.getBoundingClientRect().top+scrollY-(parseFloat(getComputedStyle(anchor).top)||0)):null;
      if(projectReel&&Math.abs(y-projectStop)<3&&window.CanopyProjects?.step(projectReel,direction)){
        lastCommit=performance.now();return;
      }
      const target=direction>0?points.find(p=>p>y+3):points.findLast(p=>p<y-3);
      if(target!==undefined){
        if(projectReel&&Math.abs(target-projectStop)<3)window.CanopyProjects?.enter(projectReel,direction);
        go(target);
      }
    }
    function wheel(event) {
      const now=performance.now(),gap=now-lastWheel;
      const delta=event.deltaY*(event.deltaMode===1?24:event.deltaMode===2?innerHeight:1);
      const magnitude=Math.abs(delta),direction=Math.sign(delta);
      // Separate physical strokes from a continuous trackpad momentum tail.
      // This classifier is independent of whether an animation is running.
      const pause=gap>=80;
      const reverse=magnitude>=3&&lastDirection&&direction!==lastDirection;
      const renewed=now-lastCommit>140&&magnitude>=14&&magnitude-lastMagnitude>=6&&magnitude>lastMagnitude*1.55;
      const wheelTick=event.deltaMode!==0||(gap>=40&&magnitude>=32&&Math.abs(magnitude-lastMagnitude)<=magnitude*.2);
      if(pause||reverse||renewed||wheelTick){
        if(latched||reverse||gap>300)amount=0;
        latched=false;
      }
      lastWheel=now;lastMagnitude=magnitude;
      if(magnitude>=2)lastDirection=direction;
      if(event.defaultPrevented){latched=true;amount=0;return;}
      event.preventDefault();
      if(latched)return;
      if(direction!==Math.sign(amount))amount=0;
      amount+=delta;
      if(Math.abs(amount)<12)return;
      latched=true;amount=0;
      requestStep(direction);
    }
    const ignoreWheel=event=>inactive()||event.ctrlKey||editable(event.target)||event.shiftKey||Math.abs(event.deltaX)>=Math.abs(event.deltaY);
    listen('wheel',event=>{if(!ignoreWheel(event))wheel(event);},{passive:false});
    listen('touchstart',event=>{
      touch=event.touches.length===1&&!inactive()&&!editable(event.target)?
        {x:event.touches[0].clientX,y:event.touches[0].clientY,used:false,horizontal:false}:null;
    },{passive:true});
    listen('touchmove',event=>{
      if(!touch||inactive()||event.touches.length!==1||touch.horizontal)return;
      const dx=touch.x-event.touches[0].clientX,dy=touch.y-event.touches[0].clientY;
      if(!touch.used&&Math.abs(dx)>Math.abs(dy)&&Math.abs(dx)>10){touch.horizontal=true;return;}
      if(Math.abs(dy)<10&&!touch.used)return;
      event.preventDefault();
      if(!touch.used&&Math.abs(dy)>=24){touch.used=true;requestStep(Math.sign(dy));}
    },{passive:false});
    listen('touchend',()=>{touch=null;},{passive:true});
    listen('touchcancel',()=>{touch=null;},{passive:true});
    listen('keydown',event=>{
      if(inactive()||event.defaultPrevented||editable(event.target)||event.metaKey||event.ctrlKey||event.altKey)return;
      if(event.key===' '&&event.target.closest?.('button,a,[role="button"]'))return;
      if(!['ArrowDown','ArrowUp','PageDown','PageUp','Home','End',' '].includes(event.key))return;
      event.preventDefault();
      if(event.repeat)return;
      if(event.key==='Home'||event.key==='End'){const points=stops();go(event.key==='Home'?points[0]:points.at(-1));}
      else requestStep(['ArrowUp','PageUp'].includes(event.key)||(event.key===' '&&event.shiftKey)?-1:1);
    });
    listen('resize',()=>{cancelAnimationFrame(frame);frame=0;moving=false;destination=null;latched=false;amount=0;velocity=0;if(projectReel)window.CanopyProjects?.stop(projectReel);announceMotion(false);});
    reduced.addEventListener('change',finish,{signal:controller.signal});
    return ()=>{cancelAnimationFrame(frame);controller.abort();if(projectReel)window.CanopyProjects?.stop(projectReel);announceMotion(false);};
  }
};
