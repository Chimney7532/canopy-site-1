# Validation

Completed against the local D1 database on October 2, 2026. All QA accounts and records are local-only; none are seeded into production.

## API integration

Passed: registration, pending-member denial, one-time administrator setup, membership approval, public-profile opt-in, connection invitation and recipient acceptance, prohibition of messages before connection, private message participant isolation, member blocking, idea-to-project conversion, project joining and approval, project-only post denial for outsiders, poll option validation and one-vote uniqueness when changing a vote, task permissions, stage transitions, administrator-only announcements, event creation, duplicate-safe RSVP, public-note moderation, private visitor inquiries, rejection of non-admin management actions, cross-origin mutation rejection, sign-out revocation and sign-in.

## Browser checks

Verified: public homepage, sample community, Build tabs, project details, local test-account sign-in, idea dialog submission and visible read-back. No console errors in the checked signed-in flow. Verified a 390-pixel project layout with no horizontal overflow. The UI uses installed accessible dialog, tab, select, checkbox and sidebar primitives.

## WebMCP

`canopy_share_idea` registered with the expected input schema and mutation annotation. A valid call created a persistent member idea and appeared in the same Build interface. An empty-title input failed intentionally without a new record. Preview mutations remain read-only.

## Build checks

TypeScript and ESLint passed before packaging. The final Sites workflow repeats the applicable source checks and production build before source push and packaging.

## Known boundaries

No email provider is connected. Email ownership verification, self-service password reset, outbound email, WebSocket chat and file uploads are not implemented. The site is initially private at the hosting layer; app-level public pages are ready for a later deliberate public launch. Member text is plain text. Stock photography does not depict an actual Canopy event.

## Editorial redesign — October 2, 2026

Compared the owner's original localhost:3000 design at 1920 × 1080 and the palette at iscanopy.com. Verified the new public and sample-member editions at 1920 pixels, the collapsed index layout at 1024 pixels, and mobile Build and calendar views at 390 pixels. No horizontal document overflow at those widths. The desktop index hides without changing the 762-pixel reading column; each feed column has its own scroll area. Checked the idea dialog, project tabs, mobile navigation drawer and calendar tab. Local test fixtures stay local. Public home, announcement rail and Explore filter public records even in a signed-in session.

## Split masthead scroll correction

Verified at 1920 × 1080: CAN and OPY start at the same 61.5-pixel vertical position. Scrolling the reading column moves OPY out of view while CAN stays at 61.5 pixels and the announcement column stays at scrollTop 0. CAN remains outside the announcement list scroller as well. Desktop focus control is in the right rail area so scrolling article actions cannot pass beneath it. Narrow screens keep the complete wordmark.

## Standard desktop width correction

The live page at the user's actual 1034 × 823 viewport loaded the split-masthead markup but hid it because its CSS was gated at 1280 pixels. Expanded independent scrolling and split headings to every multi-column layout (768 pixels and above), with wordmark sizing based on each breakpoint's announcement-column width. Verified the local page at 1034 × 823: both halves initially align at 61.5 pixels; scrolling the reading column moves only OPY. Document width remains 1034 pixels. The single-column phone layout is unchanged.

## Word chapters

Replaced cropped masthead SVG halves with real bold type. Member sections now read CANOPY, CAN SHARE, CAN TALK and CAN BUILD; public sections read CANOPY, CAN JOIN, CAN BUILD and CAN READ. At 1034 × 823, all chapter words use the same 107.182-pixel type size. CAN and the pinned BUILD heading both start at 61.5 pixels. At 1920 pixels, all use 160-pixel type. The initial OPY scrolls away; later headings pin while their section is read and are replaced by the next chapter. At 390 pixels, the full text CANOPY is visible and the document has no horizontal overflow. Checked the mobile conversation dialog. Data models and API permissions are unchanged.

## Heavy display type and scroll handoff

Large headings now use the locally hosted Archivo Black face. Confirmed that the font is loaded at 1034 × 823 and that there is no horizontal overflow at 1034 or 390 pixels. Removed chapter snapping and forced viewport-height sections. The feed retains native scrolling; the motion hook only changes outgoing text opacity using a passive scroll listener and requestAnimationFrame. Checked forward and reverse scrolling: opacity fell to 0.468 during a SHARE-to-TALK handoff and returned to 1 when scrolling back, with CAN and the pinned SHARE heading aligned at 61.5 pixels. On the phone breakpoint, the motion styles clear. Reduced-motion preferences disable the fade. No browser console errors in the checked flow.


## Logo-derived chapter lettering

- Replaced the generic display face with complete CAN/OPY vector outlines derived from the supplied logo. OPY retains the eye and star; chapter letters follow the same heavy stems and open A.
- At 1034 px, CAN and OPY share a 61.5 px top and a 94.8125 px height. No horizontal overflow. Native sticky chapter behavior is unchanged.
- At 390 px, the complete original logo fits the mobile masthead without horizontal overflow.
- TypeScript check passed. Production build is run by the publishing workflow.


## Damped reading-column scroll (earlier implementation, replaced October 5)

- Added exponential wheel damping (105 ms pixel input / 140 ms line input), immediate reversal and bounded queued travel. Touch, nested scrolling, zoom gestures and reduced-motion input bypass damping. Pointer and keyboard input cancel pending travel.
- Browser frame samples after a downward gesture progressed 0 → 90.5 → 168.5 → 239 → 294.5 → 345.5; the reverse gesture progressed 632 → 590 → 553.5 → 524.5 → 498. Both ease toward rest.
- Chapter geometry is cached on resize; scroll frames update position and opacity without repeated chapter layout reads.
- Four deterministic motion tests pass: 60/120 Hz parity, bounded settling, reversal/edges, and nonnegative frame time. TypeScript passes.


## Website / member-area separation

- `tests/edition-boundaries.mjs` passes against existing local QA fixtures for both an active administrator and an active member. Public content is identical for a guest and an authenticated website visitor (excluding their own session identity). Internal arrays remain empty, including replies, polls, messages and work-area data. Anonymous requests for member scope still return public content.
- Browser-checked navigation from the signed-in website to the real member area and back. Website has no composer or private discussion content; member actions return inside. WebMCP writing tools are only registered for active, real member pages.
- Verified the member preview and mobile drawer at 390 px; no horizontal overflow. Desktop title lettering and damping remain in place.
- TypeScript passed; the publishing workflow runs the production build. Local fixtures are not part of the deployment.


## Scroll continuity — October 5, 2026

- Replaced the custom scroll target cap and wheel-ancestor layout loop with Lenis 1.3.26. The lockfile pins the dependency. Removed the old damping helper and its obsolete arithmetic tests.
- One demand-driven animation clock advances scrolling and chapter ink, primed before the first gesture after idle. Only changed opacity values are written. Layout geometry is measured on resize, not each wheel event.
- Desktop browser wheel input traversed the full 827 px requested, settling with CAN and SHARE both at 97.5 px. Reverse input eased toward its new target. The former viewport-relative distance cap is gone.
- At 390 px the Lenis instance is absent, the inner scroll stays at zero, and native document scrolling reached 743 px. The page has no horizontal overflow. Touch input also remains native on wider touch devices (syncTouch false).
- Browser checks use automated wheel input and a narrow viewport, not physical testing on every mouse, trackpad or phone.
- TypeScript and the production build are checked before publication.
