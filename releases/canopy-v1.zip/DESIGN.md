# Design System: Canopy

Project: appgprj_6ac01704196c819182c076161c59f860

## Direction and references

An English community publication, with a public edition and a working member edition. The primary reference is the owner's original Canopy site at localhost:3000, inspected at 1920 × 1080. Its permanent navigation, oversize lettering and scroll-linked word pairings establish the character. The current design simplifies the original columns into one main reading surface. The warm paper and dark red come from iscanopy.com. Use the supplied official Canopy SVG without redrawing or substituting a leaf symbol.

## Palette

- Paper: #F4F1EA, the main page and navigation.
- Ink: #171715, titles, body and primary buttons.
- Rule: #B7B1A6, hairlines and field outlines.
- Red: #8B2E24, active navigation and occasional editorial emphasis.
- Index paper: #EFEBE3, a slight distinction for the right column.
- Secondary text: #5D554B, supporting copy.

## Type

Custom SVG lettering carries CAN and the chapter words. CAN preserves the supplied logo’s connected C/A contour; OPY retains its eye and star, with a complete O outline rebuilt where it met N. Additional letters use the same cap height, heavy stems and open A. Space Grotesk carries navigation, article headlines, dates and section numbers. Newsreader carries prose, bylines and italic emphasis. Fonts are local, with font-display: swap. Large headings use tight spacing; body text has a comfortable line height. Uppercase belongs to short labels, not paragraphs. Keep copy specific: “Share an idea,” “Join project,” “Send message.” Avoid generic claims about the community and invented numbers, testimonials or partners.

## Layout and behavior

The desktop public website has a narrow 180px navigation rail and one full-width reading surface. The opening pairs logo-derived CAN + OPY with a panoramic monochrome tree photograph. A large red italic “Come along.” sits on a paper inset at the lower edge of the photograph; short copy and one primary action, “See what’s on,” sit alongside it. On mobile, the same inset leads into a single column. This cover composition supplies the homepage's visual focus without extra decorative assets or motion. JOIN, BUILD and READ always follow the opening. Real events, projects, people and official posts populate those chapters when available. Empty chapters retain a short invitation and a useful destination, without invented activity. Partners and contact close the page. Avoid announcement sidebars, right indexes and redundant issue labels.

CAN stays at the top while OPY scrolls away and JOIN, BUILD and READ meet its baseline. A paper header band keeps the fixed title clear of body content. The band fades out before the closing content. Chapter words share a cap height; no rectangular cropping is used at the CAN/OPY join. The desktop reading surface uses Lenis 1.3.26 with lerp 0.2 and immediate direction changes. One on-demand animation clock handles scrolling and chapter opacity. Touch and reduced-motion preferences retain native behavior. Mobile uses the complete official logo in a single content stream.

The member workspace has no oversized CAN titles or animated chapters. Discussions is the landing page: one latest official announcement, a prominent “Start a discussion” action, searchable discussions and a separate announcements tab. Content occupies a centered, comfortable reading width with restrained metadata and simple separators. Other pages use ordinary page headings and the same quiet frame.

Only the current page keeps a visible navigation arrow. Other arrows draw in on hover or keyboard focus: the diagonal stem extends first, followed by the corner. On exit, the corner retracts before the stem. Hovering the current page retracts and redraws its arrow once. The arrow never scales or moves as a whole. Text, backgrounds, cards and buttons retain their resting appearance. Keyboard focus has a visible outline. Internal links keep the application, navigation and fonts mounted; the reading surface exits over 180ms and enters over 440ms. The public/member data scope is prepared before committing the new view, and font files are preloaded. This is a local history navigator, not the failing RSC client router. Downloads, modified clicks and external links retain native behavior. Reduced-motion preferences bypass the page and arrow animations. Motion lives in app/motion.css and hooks/use-page-navigation.ts.

Public pages show only public records, even when the visitor is a signed-in member. Member views retain discussion, connections, private messages, polls, project stages and tasks. Demo data remains isolated and explicitly labeled fictional and read-only.

## Components

Buttons, inputs, tabs and dialogs use square corners. Thin borders and spacing define cards. Photos are monochrome; do not invent documentary event photos. Initials stand in for missing member portraits. Keep visible labels, focus indicators and validation feedback. Installed accessible sidebar, dialog, select, tab and checkbox primitives handle interaction.

The editorial theme lives in app/editorial.css; shared functional styles remain in app/globals.css. Database and API models are documented separately in docs/DATA_MODEL.md.

## Asset provenance

- Official logo: owner's supplied Group 3.svg, copied unchanged to public/canopy-logo.svg. Favicon uses its eye/star mark.
- Archivo Black, Space Grotesk and Newsreader: Google Fonts, SIL Open Font License. License files accompany the local font files in public/fonts.
- Tree-canopy photograph: Maria Noemi Sgobba, Unsplash, https://unsplash.com/photos/green-leaf-tree-during-daytime-fhcdcQmxcFI . Used under the Unsplash License. It is a stock photograph, not a Canopy event.


## Public website and member area

The public website uses a paper navigation rail with Home, What’s on, Projects, People and About. The member area uses a warm charcoal rail (#292822), pale text and muted coral active links, with Discussions, Ideas & projects, Members and Calendar. Messages, notifications and profile are secondary links. An audience strip links each area to the other. Both share the official logo, paper background, serif prose and dark red primary actions.

Public pages present official posts without reply, voting or moderation controls. The normal website points to member sign-in; the read-only sample remains a secondary option on the membership gate. Internal composers identify their audience before submission. Public profiles and approved member notes remain opt-in.

## Complete page family

Public routes cover the calendar and event dialogs, project directory and public project details, opted-in members and approved notes, official updates, about and partners, contact, account application, sign-in and community rules. Member routes cover discussions and replies, ideas with interest and conversion controls, project stages and project-specific ideas/polls/tasks/participants, connections, calendar/RSVP, messages, notifications and profile settings. Administration covers membership review, publishing, contact inbox, note approval and reports.

Use compact workspace headings, a single reading column or purpose-built two-column layouts, and useful empty states on these pages. The project stage timeline carries status; leads change stage in a dialog. Public updates use PublicPost and expose no member interaction controls. The member idea feed uses PostCard for replies and interest. Message lists exclude the signed-in member and initially open the first available connection.

The read-only preview includes a page directory at /preview/guide and a fictional admin view. Preview examples never write to the production store. The actual admin route remains role-gated; preview availability is not a grant of admin access.


## People — member grid (current)
The member directory has three groups in order: Community, Founding members, Advisor. Each group uses the same even dot grid on cream paper. Do not subdivide by personal identities such as Researcher or Builder, and do not draw connections between people. All dots are black and have equal weight; names are always visible below each dot. The selected dot has a quiet ring and its name and identities appear in the side preview. No search bar. Keep the grid close to the Become a Canopy member link, without an empty toolbar row. Keep role, quote and optional photograph in the full-screen profile. Expand from the actual dot using the existing liquid transition. On mobile use three columns with the selected preview above. Preserve keyboard navigation and reduced motion. Sample profiles remain restricted to ?people-template=1 with a disclosure at the bottom.
