# Canopy — source handoff / 源码交接

Live version: 114
Commit: `87fc93d86ac9bca5032b8880b8dde387460e5f40`
Website: https://canopy-community-hub.kstan1767.chatgpt.site/

## Run locally / 本地运行

Use Node.js 22.13 or newer and npm. Run inside this folder:

```sh
npm ci
npm run build
npx wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_daily_smasher.sql
npx wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_high_the_order.sql
npm run dev
```

Open the Local URL printed by the terminal (normally http://localhost:5173).
Apply migrations once to a fresh local database, in the order above.
Local data lives in `.wrangler/state`; production data is not included.
For a production-style local preview after building: `npm run start -- --port 4173`.

## Editing map / 修改入口

- `site/index.html`: **current public website**, page templates, navigation and shared layout.
- `public/assets/`: page styles, interactions, images and fonts.
- `public/assets/ink-titles.js`: title morphing, eyes following the mouse and blinking.
- `public/assets/story-scroll.js`: homepage chapter scrolling.
- `public/assets/events.*`, `event-detail.*`: calendar and expanding event pages.
- `public/assets/projects.*`, `project-pages.js`: horizontal projects and detail pages.
- `public/assets/people.*`: member network and profile cards.
- `public/assets/read.*`, `read-content.js`: CAN READ and article/video panel.
- `public/assets/liquid-rail.js`, `room-flow.js`: liquid Room entrance and exit.
- `public/assets/connect-card.*`, `join-card.*`: Connect and membership forms.
- `public/favicon.svg`, `public/favicon.ico`: transparent eye white/background, white central star.
- `build/sites-worker.ts`: public HTML serving and API routing.
- `server/`, `lib/server.ts`, `app/api/route.ts`: backend and access checks.
- `db/schema.ts`, `drizzle/`: schema and migrations.
- `app/`, `components/`: retained account/setup/admin routes. Editing only `app/page.tsx` does not change the current public homepage.

Public pages use `/#home`, `/#events`, `/#projects`, `/#people`, `/#members`.
Room intentionally shows **Coming soon**; its backend is retained.
People displays labelled sample members when no public profiles exist.
Public event bootstrap data and media files are included. Production content overrides, accounts, applications, messages, sessions and uploads are not included.

## Local administrator / 本地管理员

For account/admin testing, choose your own `CANOPY_SETUP_KEY` in an ignored `.dev.vars` file before starting the local server. Register at `/join`, sign in, then open `/setup` with that key. No administrator credentials or setup-key file are included. The older README references the original owner's local `.sites-runtime/admin-setup.txt`; that file is intentionally absent here.

## Checks / 检查

```sh
node --test tests/*.test.mjs
npm run build
```

Includes the latest title-transition fix: gaze and blink geometry no longer incorrectly trigger a jump between nearby title positions.

## Publishing / 发布

Local edits do not change the live site. `.openai/hosting.json` retains the existing Site identity and `DB` binding for handback; it grants no publishing or database access. Send modified source or a diff back to the owner for review and publication. Authorized Sites editors can publish through Sites.

A different hosting provider requires Worker/D1 bindings and authentication configuration. This is not a static-only website.

## Included / 包含范围

Tracked source, lockfile, images/fonts and licence files, schema/migrations, regression tests.
Excluded: Git history, dependencies, builds, environment files, keys, local databases, caches, logs and runtime sessions.
Historical README/design/data-model documents are retained for context; this document describes the current entry points.
